# 验收报告

日期为 2026-11-22。源码目录位于 `E:\第四范式\robot-interview`。执行端为 Windows NT 10.0.26200，实际使用 Python 3.13.8 与 pytest 8.3.3。该任务执行身份调用 `wsl.exe` 返回 `Wsl/E_ACCESSDENIED`。磁盘上可见一个 Ubuntu-24.04 虚拟磁盘目录，无法从此环境确认发行版已注册、正在运行或具备 ROS 2。Windows PATH 中没有 ROS 2、colcon 或 RViz2，Docker Linux engine 管道也不可用。

## 本机执行结果

| 验证 | 结果 | 边界与证据 |
| --- | --- | --- |
| `python -m pytest -q -s -rs tests` | **27 通过，4 跳过** | 通过项包含 URDF 字节一致性、关节与 TF 拓扑、站姿和步态、位姿积分、命令限幅、无效值拒绝、Watchdog、并发所有权、Action 核心状态机、HTTP 解析及注册协议。 |
| 3 s 运动学场景 | **通过** | 注入单调时钟。初始 (0, 0)，vx=0.2 m/s，实测模拟 x=0.600000000 m、y=0.000000000 m，绝对误差 1.110e−16 m，结束后保持。此结果来自 SDK 层。 |
| URDF Git blob | **通过** | `git hash-object --no-filters` 返回 `6de9c5c2e594d440dae7fbc823fb270743f51b9f`，与上游固定提交的文件一致。 |
| Python 源码编译 | **通过** | `python -m compileall -q go1_ros2_ws/src phanthymotus-driver/interview scripts tests` 返回 0。 |
| 包清单、配置与入口解析 | **通过** | 解析 4 份 ROS package.xml、6 份 YAML/JSON/RViz 配置和无扩展名 MCP Python 入口。 |
| TCP HTTP transport | **跳过 4 项** | 可绑定 loopback socket，受限执行进程连接时返回 `WinError 10013`。HTTP handler 的独立用例读写真实格式的 HTTP 字节，传输在内存中。注册报文与定时刷新使用测试接收端替身。 |
| Headless ROS 2 启动及集成 | **被环境阻塞** | 直接执行 `scripts/ros_smoke.py` 缺 `action_msgs`，MCP 入口缺 `ament_index_python`。此处未加载真实 ROS 消息、DDS 连接、Action 服务端或 RViz2。 |
| 上游本地克隆 | **被网络阻塞** | 两次 `git clone --no-checkout` 均无法连接本机配置的 Git 代理。通过 GitHub 读取固定提交的源码和模型，已在 [源码审计](SOURCE_AUDIT.md) 记录。 |

原始 Python 测试及导入探测输出见 [HOST_TEST_LOG.txt](HOST_TEST_LOG.txt)。

## 最终 A–E 验收状态

| 项 | 当前结果 | Linux/WSL 验收 |
| --- | --- | --- |
| A · RViz2 | URDF、站姿、动静态 TF 的静态配置齐备。图形启动及运动渲染未验证。 | `bash scripts/run_demo.sh` 后查看 RViz2，执行 README 的 MoveFor 和旋转指令。 |
| B · ROS 2 | Topic、Service、Action 和标准消息代码齐备。实时消息、Action 回调、CLI 和 shutdown 未验证。 | `bash scripts/build.sh && bash scripts/smoke_test.sh`，同时查看 `ros2 topic echo /odom --once`。 |
| C · MCP | 工具契约、处理器、单位转换、注册 payload 已验证。真实 TCP、ROS 共享状态、Core 自动注册和 Dashboard 未验证。 | 运行全量 smoke，检查 MCP Goal ID 和 ROS 状态一致，再按 README 接入已启动的 Core。 |
| D · 工程测试 | 通过非 ROS 本机测试与静态检查。colcon、rosidl 产物导入及 rosbag2 未验证。 | 在具备依赖的 WSL/Ubuntu 运行构建、全量 smoke 与录制脚本。 |
| E · 可复现性 | 固定版本、原始模型、依赖、命令和测试已记录。尚无另一台 Linux 主机复现结果。 | 在新目录解压，执行 README 的检查、构建、演示与验收命令。 |

这次没有连接或控制真机。报告没有把模拟步态视为动力学验证。
