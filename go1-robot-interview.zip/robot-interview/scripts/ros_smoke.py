"""Headless integration test of the installed ROS 2 packages and actual HTTP bridge."""
import json
import math
import os
from pathlib import Path
import re
import signal
import socket
import subprocess
import tempfile
from time import monotonic
from urllib.error import URLError
from urllib.request import ProxyHandler, Request, build_opener

from action_msgs.msg import GoalStatus
from geometry_msgs.msg import Twist, TwistStamped
from go1_interfaces.action import MoveFor
from go1_mock.model import Go1Model, JOINT_NAMES, LEGS, STAND
from ament_index_python.packages import get_package_share_directory
from nav_msgs.msg import Odometry, Path as RosPath
import rclpy
from rclpy.action import ActionClient
from rclpy.qos import DurabilityPolicy, QoSProfile
from sensor_msgs.msg import BatteryState, Imu, JointState
from std_msgs.msg import String
from std_srvs.srv import Trigger
from tf2_msgs.msg import TFMessage

HTTP = build_opener(ProxyHandler({}))


def check(condition, label):
    if not condition:
        raise AssertionError(label)


def await_condition(node, predicate, label, seconds=5.0):
    end = monotonic() + seconds
    while monotonic() < end:
        if predicate():
            return
        rclpy.spin_once(node, timeout_sec=0.03)
    raise AssertionError(f"timed out: {label}")


def spin_for(node, seconds, each=None):
    end = monotonic() + seconds
    while monotonic() < end:
        if each:
            each()
        rclpy.spin_once(node, timeout_sec=0.01)


def done(node, future, label, seconds=5):
    await_condition(node, future.done, label, seconds)
    return future.result()


def mcp(url, method, params=None):
    body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}}).encode()
    try:
        with HTTP.open(Request(url, data=body, headers={"Content-Type": "application/json"}), timeout=3) as res:
            response = json.load(res)
    except URLError:
        return None
    check("result" in response, response)
    return response["result"]


def mcp_tool(url, name, **args):
    result = mcp(url, "tools/call", {"name": name, "arguments": args})
    if result is None:
        return None
    check(not result.get("isError"), result)
    return json.loads(result["content"][0]["text"])


def integration(port):
    url = f"http://127.0.0.1:{port}/mcp"
    urdf_path = Path(get_package_share_directory("go1_description")) / "urdf/go1_model.urdf"
    model = Go1Model.load(urdf_path)
    node = rclpy.create_node("go1_smoke")
    latest = {}
    parents = {}
    static_frames = set()
    transforms = {}

    def tf_cb(message, static):
        for transform in message.transforms:
            child = transform.child_frame_id
            parents.setdefault(child, set()).add(transform.header.frame_id)
            transforms[child] = transform
            if static:
                static_frames.add(child)

    def save(name, msg_type, topic):
        node.create_subscription(msg_type, topic, lambda msg: latest.__setitem__(name, msg), 10)

    def state():
        return json.loads(latest["state"].data)

    def pose():
        pos = latest["odom"].pose.pose.position
        return pos.x, pos.y

    def is_zero():
        twist = latest["odom"].twist.twist
        return (twist.linear.x, twist.linear.y, twist.angular.z) == (0.0, 0.0, 0.0)

    def stable():
        await_condition(node, is_zero, "stopped odometry")
        first = pose()
        spin_for(node, 0.22)
        check(math.dist(first, pose()) < 1e-7, "translation while stopped")

    def task_status(expected):
        return (state()["task"] or {}).get("status") == expected

    try:
        node.create_subscription(TFMessage, "/tf", lambda msg: tf_cb(msg, False), 100)
        node.create_subscription(TFMessage, "/tf_static", lambda msg: tf_cb(msg, True),
                                 QoSProfile(depth=10, durability=DurabilityPolicy.TRANSIENT_LOCAL))
        save("joints", JointState, "/joint_states")
        save("odom", Odometry, "/odom")
        save("imu", Imu, "/imu")
        save("battery", BatteryState, "/battery_state")
        save("state", String, "/go1/state")
        save("path", RosPath, "/go1/path")
        save("skeleton", String, "/go1_mock/state/joints")
        cmd = node.create_publisher(Twist, "/go1/cmd_vel", 1)
        stamped = node.create_publisher(TwistStamped, "/go1/cmd_vel_stamped", 1)
        actions = ActionClient(node, MoveFor, "/go1/move_for")
        stop = node.create_client(Trigger, "/go1/stop")
        status = node.create_client(Trigger, "/go1/status")
        check(actions.wait_for_server(timeout_sec=20), "MoveFor server missing")
        check(stop.wait_for_service(timeout_sec=10) and status.wait_for_service(timeout_sec=10), "Trigger missing")
        await_condition(node, lambda: len(latest) == 7 and len(parents) == 17 and cmd.get_subscription_count()
                        and stamped.get_subscription_count(), "ROS telemetry and TF discovery", 20)
        initialized = mcp(url, "initialize", {"protocolVersion": "2024-11-05"})
        check(initialized and initialized["protocolVersion"] == "2024-11-05", "MCP initialize")
        tools = mcp(url, "tools/list")
        check(tools and {entry["name"] for entry in tools["tools"]} == {
            "loco", "loco_state", "battery", "imu", "joints", "model",
        }, "MCP tool discovery")
        check(mcp_tool(url, "model")["urdf"] == urdf_path.read_text(encoding="utf-8"), "MCP model")
        check(mcp_tool(url, "joints", action="read")["data"]["simulated"], "MCP joints")
        check(mcp_tool(url, "imu", action="read")["data"]["available"], "MCP IMU")
        check(mcp_tool(url, "battery", action="read")["data"]["soc_pct"] > 0, "MCP battery")

        expected = {"trunk": {"odom"}}
        for leg in LEGS:
            expected.update({f"{leg}_hip": {"trunk"}, f"{leg}_thigh": {f"{leg}_hip"},
                             f"{leg}_calf": {f"{leg}_thigh"}, f"{leg}_foot": {f"{leg}_calf"}})
        check(parents == expected and static_frames == {f"{leg}_foot" for leg in LEGS}, "TF tree")
        tf_publishers = {p.node_name for p in node.get_publishers_info_by_topic("/tf")}
        check(tf_publishers == {"go1_mock", "go1_state_publisher"}, f"unexpected TF publishers: {tf_publishers}")
        initial = latest["joints"]
        check(tuple(initial.name) == JOINT_NAMES and tuple(initial.position) == STAND, "static pose")
        check(pose() == (0.0, 0.0) and latest["odom"].child_frame_id == "trunk", "initial odometry")
        check(latest["battery"].location == "simulated" and latest["imu"].linear_acceleration_covariance[0] == -1,
              "simulated sensor contract")
        check(json.loads(latest["skeleton"].data)["format"] == "sensor/skeleton", "skeleton topic")

        feedback = []
        goal = done(node, actions.send_goal_async(
            MoveFor.Goal(vx=0.2, duration_s=3.0), feedback_callback=lambda msg: feedback.append(msg.feedback.elapsed_s)
        ), "accept 3 second goal")
        check(goal.accepted, "3 second goal rejected")
        await_condition(node, lambda: pose()[0] > 0.04, "3 second goal updates Odometry")
        angles = latest["joints"].position
        check(any(abs(a - b) > 0.005 for a, b in zip(angles, STAND)), "leg animation")
        check(all(lo <= q <= hi for q, (lo, hi) in zip(angles, model.joint_limits)), "joint limits")
        # A conflicting topic and a second action must leave ownership with the first goal.
        conflict_twist = Twist()
        conflict_twist.linear.y = 0.3
        cmd.publish(conflict_twist)
        conflict = done(node, actions.send_goal_async(MoveFor.Goal(vx=0.1, duration_s=1.0)), "conflicting goal")
        check(not conflict.accepted, "competing Action accepted")
        result = done(node, goal.get_result_async(), "3 second action result")
        check(result.status == GoalStatus.STATUS_SUCCEEDED and result.result.success, "MoveFor success")
        stable()
        x, y = pose()
        error = abs(x - 0.6)
        print(f"ROS 2 3 s scenario: x={x:.9f} m, y={y:.9f} m, error={error:.6f} m", flush=True)
        check(error < 0.02 and abs(y) < 0.01, "0.6 m displacement or action arbitration")
        translation = transforms["trunk"].transform.translation
        check(math.dist((translation.x, translation.y), (x, y)) < 0.01, "translation agrees with trunk TF")
        check(len(feedback) >= 5 and feedback == sorted(feedback), "monotonic Action feedback")
        check(len(latest["path"].poses) >= 2 and state()["task"]["status"] == "succeeded", "path and task status")
        battery = latest["battery"].percentage
        check(0.84 < battery < 0.86, "mock battery percentage")

        for bad_goal in (MoveFor.Goal(vx=float("nan"), duration_s=1.0),
                         MoveFor.Goal(vx=0.1, duration_s=-1.0)):
            check(not done(node, actions.send_goal_async(bad_goal), "invalid goal rejection").accepted,
                  "invalid Action accepted")
        for value in (float("nan"), float("inf")):
            msg = Twist()
            msg.linear.x = value
            cmd.publish(msg)
            stable()
        old_message = TwistStamped()
        old_message.header.frame_id = "trunk"
        old_message.header.stamp.sec = node.get_clock().now().to_msg().sec - 5
        old_message.twist.linear.x = 0.2
        stamped.publish(old_message)
        stable()

        start_x = pose()[0]
        forward = Twist()
        forward.linear.x = 0.2
        cmd.publish(forward)
        await_condition(node, lambda: pose()[0] > start_x + 0.02, "Twist moves robot")
        await_condition(node, lambda: state()["stop_reason"] == "watchdog timeout", "watchdog motion halt")
        stable()
        check(0.04 < pose()[0] - start_x < 0.12, "watchdog displacement")

        turn = TwistStamped()
        turn.header.frame_id = "trunk"
        turn.header.stamp = node.get_clock().now().to_msg()
        turn.twist.angular.z = 0.6
        stamped.publish(turn)
        await_condition(node, lambda: state()["pose"]["yaw_rad"] > 0.03, "fresh TwistStamped turns robot")
        check(done(node, stop.call_async(Trigger.Request()), "stop service").success, "service failed")
        stable()
        orientation = transforms["trunk"].transform.rotation
        check(abs(2 * math.atan2(orientation.z, orientation.w) - state()["pose"]["yaw_rad"]) < 0.01,
              "heading agrees with trunk TF")
        status_response = done(node, status.call_async(Trigger.Request()), "status service")
        check(json.loads(status_response.message)["stop_reason"] == "stop service", "stop reason")

        cancel_goal = done(node, actions.send_goal_async(MoveFor.Goal(vx=0.2, duration_s=4.0)), "cancel goal")
        check(cancel_goal.accepted, "cancel scenario rejected")
        await_condition(node, lambda: task_status("running"), "goal running before cancel")
        cancel = done(node, cancel_goal.cancel_goal_async(), "cancel response")
        check(bool(cancel.goals_canceling), "cancel rejected")
        result = done(node, cancel_goal.get_result_async(), "canceled result")
        check(result.status == GoalStatus.STATUS_CANCELED and not result.result.success, "cancel terminal status")
        stable()

        abort_goal = done(node, actions.send_goal_async(MoveFor.Goal(vx=0.2, duration_s=4.0)), "abort goal")
        check(abort_goal.accepted, "abort scenario rejected")
        await_condition(node, lambda: not is_zero(), "moving before external stop")
        check(done(node, stop.call_async(Trigger.Request()), "external stop").success, "external stop failed")
        result = done(node, abort_goal.get_result_async(), "aborted result")
        check(result.status == GoalStatus.STATUS_ABORTED and not result.result.success, "external stop result")
        stable()

        previous = pose()
        move = mcp_tool(url, "loco", action="move", vx=0.2, duration=3.0)
        check(move and move["state"] == "accepted", "MCP MoveFor acceptance")
        await_condition(node, lambda: task_status("running") and math.dist(previous, pose()) > 0.04,
                        "MCP changes the ROS pose")
        read = mcp_tool(url, "loco_state", action="read")["data"]
        check(read["owner"] == "action" and math.dist(pose(), (read["pose"]["x_m"], read["pose"]["y_m"])) < 0.12,
              "MCP state must reflect ROS pose")
        check(read["task"]["goal_id"] == move["goal_id"], "MCP status refers to the accepted MoveFor goal")
        check(mcp_tool(url, "loco", action="stop")["applied"]["stopped"], "MCP stop")
        await_condition(node, lambda: task_status("aborted"), "MCP stop updates ROS action status")
        stable()
        print("ROS 2 TF, messages, Topic, Trigger, Action and shared MCP motion passed.", flush=True)
    finally:
        node.destroy_node()


def main():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    log_path = Path(tempfile.mkdtemp(prefix="go1-ros-smoke-")) / "launch.log"
    print(f"Headless launch log: {log_path}", flush=True)
    with log_path.open("w", encoding="utf-8") as log:
        launch = subprocess.Popen(
            ["ros2", "launch", "go1_bringup", "go1_demo.launch.py", "rviz:=false",
             f"mcp_port:={port}", "core_url:=disabled"],
            stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
        )
        rclpy.init()
        try:
            integration(port)
            check(launch.poll() is None, "launch exited unexpectedly")
        finally:
            rclpy.try_shutdown()
            if launch.poll() is None:
                launch.send_signal(signal.SIGINT)
            try:
                launch.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(launch.pid, signal.SIGKILL)
                launch.wait()
                raise AssertionError("launch did not stop within 15 seconds")
    contents = log_path.read_text(encoding="utf-8", errors="replace")
    children = set(re.findall(r"process started with pid \[(\d+)\]", contents))
    check(len(children) >= 3, "expected simulator, state publisher and MCP process")
    check(not any(Path(f"/proc/{pid}").exists() for pid in children), "launch left child processes running")
    print("All launch child processes exited.", flush=True)


if __name__ == "__main__":
    main()
